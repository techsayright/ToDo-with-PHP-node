-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2021 at 03:59 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tasknode`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignee`
--

CREATE TABLE `assignee` (
  `id` int(12) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `occupation` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assignee`
--

INSERT INTO `assignee` (`id`, `name`, `email`, `occupation`) VALUES
(1, 'darshan', 'darshan88@gmail.com', 'Web Developer '),
(2, 'nisarg', 'nisarg@ildc.com', 'JS Developer ');

-- --------------------------------------------------------

--
-- Table structure for table `subtask`
--

CREATE TABLE `subtask` (
  `id` int(11) NOT NULL,
  `subtasktitle` varchar(200) NOT NULL,
  `subtask_des` varchar(300) NOT NULL,
  `StDateTime` text NOT NULL,
  `dueDateTime` text NOT NULL,
  `endDateTime` text NOT NULL,
  `subtaskassignee` varchar(100) NOT NULL,
  `taskid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subtask`
--

INSERT INTO `subtask` (`id`, `subtasktitle`, `subtask_des`, `StDateTime`, `dueDateTime`, `endDateTime`, `subtaskassignee`, `taskid`) VALUES
(1, 'Project task list templates & tools', 'A task list can be easily managed using spreadsheets like Microsoft Excel or Google Sheets. Most office suites also come with templates to help you manage tasks. Here are some templates you will find useful.', '17-06-2021 03:00', '30-06-2021 05:00', '24-06-2021 04:00', 'darshan', 1);

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(12) NOT NULL,
  `title` varchar(200) NOT NULL,
  `title_des` varchar(500) NOT NULL,
  `StDateTime` text NOT NULL,
  `dueDateTime` text NOT NULL,
  `endDateTime` text NOT NULL,
  `assignee` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `title`, `title_des`, `StDateTime`, `dueDateTime`, `endDateTime`, `assignee`) VALUES
(1, 'Establish project scope', 'The project scope decides what’s included in a project and what isn’t.\r\nIt documents the goals of a project and defines the deliverables. These are decided based on the stakeholders’ priorities and constraints and the risks to the project.', '13-06-2021 12:00', '15-06-2021 12:00', '13-07-2021 05:00', 'darshan'),
(2, 'Create a work breakdown structure (WBS)', 'To create a WBS, break down the project into phases. At the end of each phase, a part of the project is delivered. To identify project phases, an easy way is to split the project into smaller deliverables.', '01-08-2021 08:00', '30-10-2021 05:00', '30-06-2021 07:00', 'nisarg'),
(3, 'Break work phase into tasks', 'Now that the work phases are identified, you can further break each phase into individual tasks. For each task, you can also include the task’s attributes. These include the estimated effort, responsible team members.', '21-10-2022 04:00', '09-06-2022 02:00', '15-06-2023 03:00', 'darshan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignee`
--
ALTER TABLE `assignee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subtask`
--
ALTER TABLE `subtask`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subtask_ibfk_1` (`taskid`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignee`
--
ALTER TABLE `assignee`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `subtask`
--
ALTER TABLE `subtask`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
