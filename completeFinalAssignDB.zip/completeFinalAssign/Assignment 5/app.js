const path = require('path');
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const { join } = require('path');
const app = express();


const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    multipleStatements: true,
    database: 'tasknode'
});

connection.connect(function (error) {
    if (!!error) console.log(error);
    else console.log('Database Connected!');
});

//set views file
app.set('views', path.join(__dirname, 'views'));

//set view engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));



app.get('/', (req, res) => {
    let sql = "SELECT * FROM task";
    let query = connection.query(sql, (err, rows) => {
        if (err) throw err;
        res.render('user_index', {
            title: 'Assignment :-5 Task Managment',
            taskp: rows
        });
    });
});

// ADD,Edit,Delete Task

app.get('/add', (req, res) => {
    let sql = "SELECT name FROM assignee";
    let query = connection.query(sql, (err, rows) => {
        if (err) throw err;
        res.render('user_add', {
            title: 'Assignment :-5 Task Managment',
            taskp: rows
        });
    });
});

app.post('/save', (req, res) => {

    let data = { title: req.body.title, title_des: req.body.description, StDateTime: req.body.start, dueDateTime: req.body.due, endDateTime: req.body.end, assignee: req.body.assignee };
    let sql = "INSERT INTO task SET ?";
    let query = connection.query(sql, data, (err, results) => {
        if (err) throw err;
        res.redirect('/');
    });
});

app.get('/edit/:userId', (req, res) => {
    const userId = req.params.userId;
    let sql = `Select * from task where id = ${userId} ; select name from assignee `;
    let query = connection.query(sql, (err, results) => {
        if (err) throw err;
        res.render('user_edit', {
            title: 'Assignment :-5 Task Managment',
            taskp: results[0],
            ass: results[1]
        });
    });

});
app.post('/update', (req, res) => {
    const userId = req.body.id;
    let sql = "update task SET title='" + req.body.title + "',  title_des='" + req.body.description + "',StDateTime='" + req.body.start + "',  dueDateTime='" + req.body.due + "',endDateTime='" + req.body.end + "',  assignee='" + req.body.assignee + "' where id =" + userId;
    let query = connection.query(sql, (err, results) => {
        if (err) throw err;
        res.redirect('/');
    });
});


app.get('/delete/:userId', (req, res) => {
    const userId = req.params.userId;
    let sql = `DELETE from task where id = ${userId}`;
    let query = connection.query(sql, (err, result) => {
        if (err) throw err;
        res.redirect('/');
    });
});


// ADD,Edit,Delete Assignee Task 

app.get('/assignee', (req, res) => {
    let sql = "SELECT * FROM  assignee";
    let query = connection.query(sql, (err, rows) => {
        if (err) throw err;
        res.render('assignee_index', {
            title: 'Assignment :-5 Task Managment',
            assigneep: rows
        });
    });
});


app.get('/add_assignee', (req, res) => {
    res.render('assignee_add', {
        title: 'Assignment :-5 Task Managment'
    });
});

app.post('/save_assignee', (req, res) => {
    let data = { name: req.body.name, email: req.body.email, occupation: req.body.occupation };
    let sql = "INSERT INTO assignee SET ?";
    let query = connection.query(sql, data, (err, results) => {
        if (err) throw err;
        res.redirect('/assignee');
    });
});

app.get('/edit_assignee/:assigneeId', (req, res) => {
    const assigneeId = req.params.assigneeId;
    let sql = `Select * from assignee where id = ${assigneeId}`;
    let query = connection.query(sql, (err, result) => {
        if (err) throw err;
        res.render('assignee_edit', {
            title: 'Assignment :-5 Task Managment',
            assigneep: result[0]
        });
    });
});


app.post('/update_assignee', (req, res) => {
    const assigneeId = req.body.id;
    let sql = "update assignee SET name='" + req.body.name + "',  email='" + req.body.email + "',occupation='" + req.body.occupation + "' where id =" + assigneeId;
    let query = connection.query(sql, (err, results) => {
        if (err) throw err;
        res.redirect('/assignee');
    });
});


app.get('/delete_assignee/:assigneeId', (req, res) => {
    const assigneeId = req.params.assigneeId;
    let sql = `DELETE from assignee where id = ${assigneeId}`;
    let query = connection.query(sql, (err, result) => {
        if (err) throw err;
        res.redirect('/assignee');
    });
});

// ADD,Edit,Delete  SubTask

app.get('/addsubtask/:userId', (req, res) => {
    const userId = req.params.userId;
    let sql = `Select * from task where id = ${userId} ; select name from assignee `;
    let query = connection.query(sql, (err, results) => {
        if (err) throw err;
        res.render('subtask_add', {
            title: 'Assignment :-5 Task Managment',
            taskp: results[0],
            ass: results[1]
        });
    });

});
app.post('/subTaskSave', (req, res) => {

    let data = { subtasktitle: req.body.title, subtask_des: req.body.description, StDateTime: req.body.start, dueDateTime: req.body.due, endDateTime: req.body.end, subtaskassignee: req.body.assignee, taskid: req.body.taskid };
    let sql = "INSERT INTO subtask SET ?";
    let query = connection.query(sql, data, (err, results) => {
        if (err) throw err;
        res.redirect('/');
    });
});

app.get('/viewsubtask/:userId', (req, res) => {
    const userId = req.params.userId;
    let sql = `SELECT * FROM subtask where taskid = ${userId}; Select * from task where id = ${userId}`;
    let query = connection.query(sql, (err, rows) => {
        if (err) throw err;
        res.render('subtask_index', {
            title: 'Assignment :-5 Task Managment',
            tasksub: rows[0],
            tasks: rows[1]
            
        });
    });
});
app.get('/viewsubtask/edit_subtask/:userId', (req, res) => {
    const userId = req.params.userId;
    let sql = `Select * from subtask where id = ${userId} ; select name from assignee `;
    let query = connection.query(sql, (err, results) => {
        if (err) throw err;
        res.render('subtask_edit', {
            title: 'Assignment :-5 Task Managment',
            taskp: results[0],
            ass: results[1]
        });
    });

});
app.post('/update_subtask', (req, res) => {
    const userId = req.body.id;
    let sql = "update subtask SET subtasktitle='" + req.body.title + "',  subtask_des='" + req.body.description + "',StDateTime='" + req.body.start + "',  dueDateTime='" + req.body.due + "',endDateTime='" + req.body.end + "',  subtaskassignee='" + req.body.assignee + "' where id =" + userId;
    let query = connection.query(sql, (err, results) => {
        if (err) throw err;
        res.redirect('/');
    });
});


app.get('/viewsubtask/delete_subtask/:userId', (req, res) => {
    const userId = req.params.userId;
    let sql = `DELETE from subtask where id = ${userId}`;
    let query = connection.query(sql, (err, result) => {
        if (err) throw err;
        res.redirect('/');
    });
});

// Server Listening
app.listen(3000, () => {
    console.log('Server is running at port 3000');
});